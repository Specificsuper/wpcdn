<?php

/*
            /$$            
    /$$    /$$$$            
   | $$   |_  $$    /$$$$$$$
 /$$$$$$$$  | $$   /$$_____/
|__  $$__/  | $$  |  $$$$$$ 
   | $$     | $$   \____  $$
   |__/    /$$$$$$ /$$$$$$$/
          |______/|_______/ 
================================
        Keep calm and get rich.
                    Is the best.

  	@Author: Dami
  	@Date:   2018-10-14 16:45:48
  	@Last Modified by:   Dami
  	@Last Modified time: 2019-11-14 07:59:19

*/
if( !class_exists('Nc_Store_Skin') ) :
class Nc_Store_Skin extends WP_Upgrader_Skin {

    public function feedback( $stream, ...$args ){

    }

    public function header(){

    }

	public function footer(){

	}
}
endif;